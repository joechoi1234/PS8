
def compmonthlysales(sales, forecastperc):
  monthlysales = (sales * (1 + forecastperc))
  return monthlysales


response = input("Do you want to run this program?(Yes or No): ")
  
while response == "Yes" or "yes":
    lastname = input("Enter last name: ")
    month = input("Enter sales month(Full month name with capitalization): ")
    sales = int(input("Enter sales: "))

    if month == ("January" or "February" or "March"):
      forecastperc = .10
    elif month == ("April" or "May" or "June"):
      forecastperc = .15
    elif month == ("July" or "August" or "September"):
      forecastperc = .20
    else:
      forecastperc = .25
  
    monthlysales = compmonthlysales(sales, forecastperc)
    print("Monthly sales: " , monthlysales)
    print("Forecast percent: " , forecastperc)
    response = input("Do you want to run this program?: ")
  





  

