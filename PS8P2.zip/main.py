
def compsquarefoot(length, width, height):
  squarefoot = ((2 * length * width) + (2 * length * height) + (2 * width * height))
  return squarefoot

response = input("Do you want to repeatedly run this program?(Yes or No): ")

while response == "Yes" or "yes":
  length = int(input("Enter length of room: "))
  width = int(input("Enter width of room: "))
  height = int(input("Enter height of room: "))
                     
  
  squarefoot = compsquarefoot(length, width, height)
  gallons = int((squarefoot / 50))
  print("Square footage: " , squarefoot)
  print("Gallons needed: " , gallons)
  response = input("Do you want to run this program again?: ")
  


  