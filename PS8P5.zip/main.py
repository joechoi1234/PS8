
count = 0.0
count2 = 0.0

def compmarketvalue(county, valueperc):
  marketvalue = (homevalue * valueperc)         
  return marketvalue

response = input("Do you want to repeatedly run this program(yes or no): ")

while response == "yes" or "Yes":
  county = input("Enter county name: ")
  homevalue = int(input("Enter value of home: "))
  if county == "Cook":
    valueperc = .90
  elif county == "DuPage":
    valueperc = .80
  elif county == "McHenry": 
    valueperc = .75
  elif county == "Kane": 
    valueperc = .60
  else:
    valueperc = .70

  marketvalue = compmarketvalue(county, valueperc)
  count = count + marketvalue
  count2 = count2 + homevalue
 
  print("Market value: " , homevalue)
  print("Assessed value: " , marketvalue)
  print("Total assessed value: " , count)
  print("Total market value: " , count2)
  response = input("Do you wnat to run this program again?: ")
  