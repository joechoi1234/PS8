
count = 0.0
salesum = 0.0
count2 = 0.0

def comptotalprice(make, model, msrp):
  totalprice = (msrp - discount)
  return totalprice


response = input("Do you want to repeatedly run this program: ")

while response == "Yes" or "yes":
  make = input("Enter make of car: ")
  model = input("Enter model of car: ")
  msrp = int(input("Enter msrp price of car: "))
  eresponse = input("Is vehicle electric?: ")

  if make == "Honda" and model == "Accord":
    discount = msrp * .10
  elif make == "Toyota" and model == "Rav4":
    discount = msrp * .15
  elif eresponse == "Yes":
    discount = msrp * .30
  else: 
    discount = msrp * .05

  totalprice = comptotalprice(make, model, msrp)
  tax = (msrp * .07)
  finalprice = totalprice + tax
  
  
  salesum = totalprice
  count = count + msrp
  count2 = count2 + salesum

  print("Total: " , finalprice)
  print("MSRP sum: " , count)
  print("Car sale sum: " , count2)
  response = input("Do you want to run this program: ")
    
    
    

  