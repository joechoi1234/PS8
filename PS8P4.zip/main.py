
count = 0.0


def compticketprice(miles):
  ticketprice = ticket
  return ticketprice

response = input("Do you want to repeatedly run this program: ")

while response == "Yes" or "yes":
  lastname = input("Enter last name: ")
  miles = int(input("How many miles from down town Chicago?: "))
  if miles >= 30:
    ticket = 12.00
  elif miles >= 20 and miles < 29:
    ticket = 10.00
  elif miles >= 10 and miles < 19:
    ticket = 8.00
  else: 
    ticket = 5.00

  count = count + ticket

  ticketprice = compticketprice(miles)
  print("Last name: " , lastname)
  print("Ticket price: $" , ticket)
  print("Sum of tickets: $" , count)
  response = input("Do you want to run this program: ")
  
  